# Password dan salt
password="password123"
salt=$(openssl rand -hex 16)  # Generate salt acak 16 byte

# Menghasilkan hash dengan argon2
hash=$(echo -n "$password" | argon2 "$salt" -id -m 18 -t 5 -p 4 -e)

# Tampilkan hash yang dihasilkan
echo "Hash: $hash"
