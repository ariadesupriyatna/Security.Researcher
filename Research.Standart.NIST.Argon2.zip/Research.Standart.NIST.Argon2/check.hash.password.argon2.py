from argon2 import PasswordHasher
import base64

# Password yang ingin diperiksa
password = "password123"

# Salt yang digunakan (harus sama dengan yang digunakan di Bash)
salt = "MDlmYjA5MDllNWNkZGVmMDQ4YWEwMTEzODlmMDdhOTc"  # Salt Base64 dari hasil openssl rand

# Hash yang dihasilkan di Bash (harus dicocokkan dengan hasil dari Bash)
stored_hash = "$argon2id$v=19$m=262144,t=5,p=4$" + salt + "$u9/TVZMdxHkDTsc6QStDN0IAQS7vzg4zoneZ5yEQh+g"

# Membuat objek PasswordHasher dengan parameter yang sama seperti di Bash
ph = PasswordHasher(
    time_cost=5,          # Iterasi (time cost)
    memory_cost=262144,   # Memory cost dalam KB (256 MB)
    parallelism=4,        # Thread paralel
)

# Verifikasi apakah kata sandi cocok dengan hash yang disimpan
try:
    ph.verify(stored_hash, password)
    print("Password valid!")
except:
    print("Password invalid?")
