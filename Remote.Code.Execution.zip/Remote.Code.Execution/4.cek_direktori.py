import subprocess

result = subprocess.run("pwd", shell=True, capture_output=True, text=True)
print("semua file yang ada:", result.stdout.strip())