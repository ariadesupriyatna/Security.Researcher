import subprocess

result = subprocess.run("ls -all /", shell=True, capture_output=True, text=True)
print("semua file yang ada:", result.stdout.strip())