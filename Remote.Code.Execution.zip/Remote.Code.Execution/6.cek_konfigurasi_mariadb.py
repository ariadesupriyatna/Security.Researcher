import subprocess

result = subprocess.run("cat /etc/mysql/mariadb.cnf", shell=True, capture_output=True, text=True)
print("semua file yang ada:", result.stdout.strip())